package com.example.service

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

data class LocationInfo(
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val accuracy: Float = 0f,
    val speed: Float = 0f,
    val city: String = "पता लगाया जा रहा है...",
    val state: String = "",
    val fullAddress: String = "लाइव GPS सिग्नल कनेक्ट हो रहा है...",
    val isTracking: Boolean = false,
    val lastUpdatedTime: Long = System.currentTimeMillis()
)

class LocationTracker(private val context: Context) : LocationListener {

    companion object {
        private const val TAG = "AmmuLocationTracker"
        @Volatile
        private var instance: LocationTracker? = null

        fun getInstance(context: Context): LocationTracker {
            return instance ?: synchronized(this) {
                instance ?: LocationTracker(context.applicationContext).also { instance = it }
            }
        }
    }

    private val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
    private val scope = CoroutineScope(Dispatchers.IO)

    private val _locationInfo = MutableStateFlow(LocationInfo())
    val locationInfo: StateFlow<LocationInfo> = _locationInfo.asStateFlow()

    fun hasLocationPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }

    @SuppressLint("MissingPermission")
    fun startTracking() {
        if (!hasLocationPermission()) {
            _locationInfo.value = _locationInfo.value.copy(
                fullAddress = "लोकेशन परमिशन की आवश्यकता है",
                isTracking = false
            )
            return
        }

        try {
            val hasGps = locationManager?.isProviderEnabled(LocationManager.GPS_PROVIDER) == true
            val hasNetwork = locationManager?.isProviderEnabled(LocationManager.NETWORK_PROVIDER) == true

            // Fetch last known location first for instantaneous display
            val lastGps = if (hasGps) locationManager?.getLastKnownLocation(LocationManager.GPS_PROVIDER) else null
            val lastNetwork = if (hasNetwork) locationManager?.getLastKnownLocation(LocationManager.NETWORK_PROVIDER) else null
            val bestLast = lastGps ?: lastNetwork

            if (bestLast != null) {
                updateLocationDetails(bestLast)
            }

            if (hasGps) {
                locationManager?.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    5000L, // 5 seconds
                    5f,    // 5 meters
                    this
                )
            }
            if (hasNetwork) {
                locationManager?.requestLocationUpdates(
                    LocationManager.NETWORK_PROVIDER,
                    5000L,
                    5f,
                    this
                )
            }

            _locationInfo.value = _locationInfo.value.copy(isTracking = true)
            Log.i(TAG, "Location tracking started")
        } catch (e: Exception) {
            Log.e(TAG, "Error starting location tracking", e)
        }
    }

    fun stopTracking() {
        try {
            locationManager?.removeUpdates(this)
            _locationInfo.value = _locationInfo.value.copy(isTracking = false)
            Log.i(TAG, "Location tracking stopped")
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping location tracking", e)
        }
    }

    override fun onLocationChanged(location: Location) {
        updateLocationDetails(location)
    }

    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}

    private fun updateLocationDetails(location: Location) {
        scope.launch {
            val geocoded = reverseGeocode(location.latitude, location.longitude)
            _locationInfo.value = LocationInfo(
                latitude = location.latitude,
                longitude = location.longitude,
                accuracy = location.accuracy,
                speed = location.speed,
                city = geocoded.first,
                state = geocoded.second,
                fullAddress = geocoded.third,
                isTracking = true,
                lastUpdatedTime = System.currentTimeMillis()
            )
        }
    }

    private suspend fun reverseGeocode(lat: Double, lon: Double): Triple<String, String, String> = withContext(Dispatchers.IO) {
        try {
            val geocoder = Geocoder(context, Locale("hi", "IN"))
            @Suppress("DEPRECATION")
            val addresses: List<Address>? = geocoder.getFromLocation(lat, lon, 1)
            if (!addresses.isNullOrEmpty()) {
                val addr = addresses[0]
                val city = addr.locality ?: addr.subAdminArea ?: addr.adminArea ?: "भारत"
                val state = addr.adminArea ?: ""
                val thoroughfare = addr.subLocality ?: addr.thoroughfare ?: ""
                val formatted = listOfNotNull(thoroughfare.takeIf { it.isNotBlank() }, city, state).joinToString(", ")
                return@withContext Triple(city, state, formatted.ifBlank { "अक्षांश: $lat, देशांतर: $lon" })
            }
        } catch (e: Exception) {
            Log.e(TAG, "Geocoding error", e)
        }
        return@withContext Triple("वर्तमान स्थान", "", "अक्षांश: ${String.format(Locale.US, "%.4f", lat)}, देशांतर: ${String.format(Locale.US, "%.4f", lon)}")
    }

    fun getSpokenCurrentLocation(): String {
        val info = _locationInfo.value
        return if (info.latitude != 0.0 && info.longitude != 0.0) {
            if (info.city.isNotBlank() && info.city != "पता लगाया जा रहा है...") {
                "कमांडर! आप अभी ${info.fullAddress} में मौजूद हैं। आपकी लाइव लोकेशन एक्टिव है!"
            } else {
                "कमांडर! आपकी लोकेशन अक्षांश ${String.format(Locale.US, "%.2f", info.latitude)} और देशांतर ${String.format(Locale.US, "%.2f", info.longitude)} पर ट्रैक हो रही है!"
            }
        } else {
            "कमांडर! कृपया लोकेशन जीपीएस ऑन करें, मैं तुरंत आपकी लाइव जगह ट्रैक करके बता देती हूँ!"
        }
    }
}
