package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.local.AppDatabase
import com.example.data.local.entities.AchievementEntity
import com.example.data.local.entities.ChatMessageEntity
import com.example.data.local.entities.ChatSessionEntity
import com.example.data.local.entities.FlashcardEntity
import com.example.data.local.entities.TaskEntity
import com.example.data.local.entities.UserProfileEntity
import com.example.data.remote.GeminiApiClient
import com.example.data.remote.GeminiMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NikhilRepository(private val context: Context) {
    private val db = AppDatabase.getDatabase(context)
    private val chatDao = db.chatDao()
    private val taskDao = db.taskDao()
    private val flashcardDao = db.flashcardDao()
    private val userProfileDao = db.userProfileDao()

    private val prefs: SharedPreferences = context.getSharedPreferences("nikhil_prefs", Context.MODE_PRIVATE)

    // Settings Keys
    companion object {
        private const val KEY_CUSTOM_API_KEY = "custom_gemini_api_key"
        private const val KEY_AUTO_SPEAK = "auto_speak_responses"
        private const val KEY_THEME_MODE = "theme_mode" // "DARK", "LIGHT", "SYSTEM"
        private const val KEY_SPEECH_RATE = "speech_rate"
        private const val KEY_SPEECH_PITCH = "speech_pitch"
        private const val KEY_IS_LOGGED_IN = "is_user_logged_in"
        private const val KEY_USER_NAME = "logged_user_name"
        private const val KEY_USER_EMAIL = "logged_user_email"
        private const val KEY_AUTH_PROVIDER = "logged_auth_provider"
        private const val KEY_IS_OWNER = "is_owner_user"
        private const val KEY_GLOBAL_BROADCAST = "global_broadcast_msg"
        private const val KEY_SAVVY_ATTITUDE = "savvy_attitude_enabled"
    }

    // Auth State getters & setters
    fun isUserLoggedIn(): Boolean = prefs.getBoolean(KEY_IS_LOGGED_IN, false)
    fun setUserLoggedIn(loggedIn: Boolean, name: String = "", email: String = "", provider: String = "", isOwner: Boolean = false) {
        prefs.edit()
            .putBoolean(KEY_IS_LOGGED_IN, loggedIn)
            .putString(KEY_USER_NAME, name)
            .putString(KEY_USER_EMAIL, email)
            .putString(KEY_AUTH_PROVIDER, provider)
            .putBoolean(KEY_IS_OWNER, isOwner)
            .apply()
    }
    fun getLoggedUserName(): String = prefs.getString(KEY_USER_NAME, "अमन का दोस्त") ?: "अमन का दोस्त"
    fun getLoggedUserEmail(): String = prefs.getString(KEY_USER_EMAIL, "") ?: ""
    fun getLoggedAuthProvider(): String = prefs.getString(KEY_AUTH_PROVIDER, "GOOGLE") ?: "GOOGLE"
    fun isOwnerUser(): Boolean = prefs.getBoolean(KEY_IS_OWNER, false)
    fun setOwnerUser(isOwner: Boolean) = prefs.edit().putBoolean(KEY_IS_OWNER, isOwner).apply()

    fun getGlobalBroadcastMessage(): String = prefs.getString(KEY_GLOBAL_BROADCAST, "👑 अमन (App Owner) द्वारा संचालित - अम्मू AI सुपर एक्टिव है!") ?: ""
    fun setGlobalBroadcastMessage(msg: String) = prefs.edit().putString(KEY_GLOBAL_BROADCAST, msg).apply()

    fun isSavvyAttitudeEnabled(): Boolean = prefs.getBoolean(KEY_SAVVY_ATTITUDE, true)
    fun setSavvyAttitudeEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_SAVVY_ATTITUDE, enabled).apply()

    // Settings getters & setters
    fun getCustomApiKey(): String {
        val vaultKey = com.example.service.SecurityShieldManager.getGeminiApiKey(context)
        if (vaultKey.isNotBlank()) return vaultKey
        return prefs.getString(KEY_CUSTOM_API_KEY, "") ?: ""
    }
    fun setCustomApiKey(key: String) {
        val trimmed = key.trim()
        com.example.service.SecurityShieldManager.saveGeminiApiKey(context, trimmed)
        prefs.edit().putString(KEY_CUSTOM_API_KEY, trimmed).apply()
    }

    fun isAutoSpeakEnabled(): Boolean = prefs.getBoolean(KEY_AUTO_SPEAK, false)
    fun setAutoSpeakEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_AUTO_SPEAK, enabled).apply()

    fun getThemeMode(): String = prefs.getString(KEY_THEME_MODE, "DARK") ?: "DARK"
    fun setThemeMode(mode: String) = prefs.edit().putString(KEY_THEME_MODE, mode).apply()

    fun getSpeechRate(): Float = prefs.getFloat(KEY_SPEECH_RATE, 1.05f)
    fun setSpeechRate(rate: Float) = prefs.edit().putFloat(KEY_SPEECH_RATE, rate).apply()

    fun getSpeechPitch(): Float = prefs.getFloat(KEY_SPEECH_PITCH, 1.25f)
    fun setSpeechPitch(pitch: Float) = prefs.edit().putFloat(KEY_SPEECH_PITCH, pitch).apply()

    // Database Flows
    val chatSessions: Flow<List<ChatSessionEntity>> = chatDao.getAllSessions()
    val allTasks: Flow<List<TaskEntity>> = taskDao.getAllTasks()
    val allFlashcards: Flow<List<FlashcardEntity>> = flashcardDao.getAllFlashcards()
    val userProfile: Flow<UserProfileEntity?> = userProfileDao.getUserProfile()
    val achievements: Flow<List<AchievementEntity>> = userProfileDao.getAllAchievements()

    fun getMessagesForSession(sessionId: Long): Flow<List<ChatMessageEntity>> =
        chatDao.getMessagesForSession(sessionId)

    // Chat Operations
    suspend fun createNewSession(title: String = "अम्मू से बातचीत", personality: String = "Ammu"): Long {
        val session = ChatSessionEntity(title = title, personality = personality)
        val id = chatDao.insertSession(session)
        val greetingText = "अरे सुनो ना! मैं तुम्हारी अम्मू (Ammu) हूँ। जब भी तुम्हारा बात करने का मन हो, मुझसे कोई भी सवाल पूछो या दिल की बात कहो - मैं हमेशा तुम्हारे साथ हूँ!"
        chatDao.insertMessage(
            ChatMessageEntity(
                sessionId = id,
                role = "assistant",
                content = greetingText
            )
        )
        return id
    }


    suspend fun sendMessage(
        sessionId: Long,
        userText: String,
        personality: String,
        imageUri: String? = null,
        imageBase64: String? = null
    ): ChatMessageEntity = withContext(Dispatchers.IO) {
        // 1. Insert user message
        val userMsg = ChatMessageEntity(
            sessionId = sessionId,
            role = "user",
            content = userText.ifBlank { "कृपया इस फ़ोटो को देखें और इसके बारे में बताएँ / एडिट करने का सुझाव दें" },
            imageUri = imageUri
        )
        chatDao.insertMessage(userMsg)

        // 2. Fetch conversation history for context
        val historyList = chatDao.getMessagesForSession(sessionId).firstOrNull() ?: emptyList()
        val geminiHistory = historyList.mapIndexed { index, item ->
            val isLast = index == historyList.size - 1
            GeminiMessage(
                role = if (item.role == "user") "user" else "model",
                text = item.content,
                imageBase64 = if (isLast) imageBase64 else null
            )
        }

        // 3. Query Gemini API
        val apiKey = getCustomApiKey()
        val responseResult = GeminiApiClient.generateResponse(
            conversation = geminiHistory,
            personality = personality,
            customApiKey = apiKey
        )

        val assistantText = responseResult.getOrDefault("System encountered an anomaly generating reply.")

        // 4. Save assistant response
        val assistantMsg = ChatMessageEntity(
            sessionId = sessionId,
            role = "assistant",
            content = assistantText
        )
        val savedId = chatDao.insertMessage(assistantMsg)

        // 5. Update session title & timestamp
        val session = chatDao.getSessionById(sessionId)
        if (session != null) {
            val updatedTitle = if (session.title == "New Conversation" && userText.isNotBlank()) {
                userText.take(30) + (if (userText.length > 30) "..." else "")
            } else {
                session.title
            }
            chatDao.updateSession(session.copy(title = updatedTitle, updatedAt = System.currentTimeMillis()))
        }

        // 6. Reward XP and check achievements
        addXpAndCoins(xpGain = 15, coinGain = 5, isMessage = true)

        assistantMsg.copy(id = savedId)
    }

    suspend fun insertDirectMessagePair(
        sessionId: Long,
        userText: String,
        assistantText: String,
        userImageUri: String? = null,
        assistantImageUri: String? = null
    ): ChatMessageEntity = withContext(Dispatchers.IO) {
        val userMsg = ChatMessageEntity(
            sessionId = sessionId,
            role = "user",
            content = userText,
            imageUri = userImageUri
        )
        chatDao.insertMessage(userMsg)

        val assistantMsg = ChatMessageEntity(
            sessionId = sessionId,
            role = "assistant",
            content = assistantText,
            imageUri = assistantImageUri
        )
        val savedId = chatDao.insertMessage(assistantMsg)
        addXpAndCoins(xpGain = 15, coinGain = 5, isMessage = true)
        assistantMsg.copy(id = savedId)
    }

    suspend fun clearCurrentSession(sessionId: Long) {
        chatDao.deleteMessagesForSession(sessionId)
    }

    suspend fun deleteSession(sessionId: Long) {
        chatDao.deleteMessagesForSession(sessionId)
        chatDao.deleteSession(sessionId)
    }

    // Task Operations
    suspend fun addTask(title: String, description: String = "", priority: String = "MEDIUM", dueDate: String = "Today") {
        taskDao.insertTask(
            TaskEntity(
                title = title,
                description = description,
                priority = priority,
                dueDate = dueDate
            )
        )
        addXpAndCoins(xpGain = 10, coinGain = 2)
    }

    suspend fun toggleTaskCompleted(task: TaskEntity) {
        val updated = task.copy(isCompleted = !task.isCompleted)
        taskDao.updateTask(updated)
        if (updated.isCompleted) {
            addXpAndCoins(xpGain = 25, coinGain = 10)
            checkAchievement("task_master")
        }
    }

    suspend fun deleteTask(task: TaskEntity) {
        taskDao.deleteTask(task)
    }

    // Flashcard Operations
    suspend fun addFlashcard(topic: String, question: String, answer: String, difficulty: String = "Medium") {
        flashcardDao.insertFlashcard(
            FlashcardEntity(
                topic = topic,
                question = question,
                answer = answer,
                difficulty = difficulty
            )
        )
    }

    suspend fun toggleFlashcardMastered(card: FlashcardEntity) {
        val updated = card.copy(isMastered = !card.isMastered)
        flashcardDao.updateFlashcard(updated)
        if (updated.isMastered) {
            addXpAndCoins(xpGain = 20, coinGain = 5)
        }
    }

    suspend fun deleteFlashcard(card: FlashcardEntity) {
        flashcardDao.deleteFlashcard(card)
    }

    // Gamification & Profile Operations
    suspend fun initializeDefaultsIfNeeded() = withContext(Dispatchers.IO) {
        // Init profile
        val currentProfile = userProfileDao.getUserProfileOnce()
        if (currentProfile == null) {
            userProfileDao.insertOrUpdateProfile(
                UserProfileEntity(
                    id = 1,
                    userName = "Commander",
                    userTitle = "Quantum Initiate",
                    xp = 150,
                    level = 1,
                    coins = 60,
                    streakDays = 1,
                    lastCheckInDate = ""
                )
            )
        }

        // Seed default achievements
        val defaultAchievements = listOf(
            AchievementEntity("first_contact", "First Contact", "Send your first message to Nikhil AI", "ic_chat", 50, true),
            AchievementEntity("voice_pilot", "Voice Comm Pioneer", "Activate JARVIS voice mode", "ic_mic", 75, false),
            AchievementEntity("scholar", "Academic Master", "Complete your first AI study session", "ic_school", 100, false),
            AchievementEntity("task_master", "Executive Precision", "Complete 5 productivity tasks", "ic_check", 120, false),
            AchievementEntity("streak_champion", "7-Day Neural Sync", "Maintain a 7-day daily streak", "ic_fire", 200, false)
        )
        userProfileDao.insertAchievements(defaultAchievements)

        // Seed default flashcards if none
        val currentCards = flashcardDao.getAllFlashcards().firstOrNull()
        if (currentCards.isNullOrEmpty()) {
            val starterCards = listOf(
                FlashcardEntity(topic = "Computer Science", question = "What is the time complexity of binary search on a sorted array?", answer = "O(log n)", difficulty = "Easy"),
                FlashcardEntity(topic = "Artificial Intelligence", question = "What is the Transformer architecture mechanism that computes relationships between all tokens?", answer = "Self-Attention Mechanism", difficulty = "Medium"),
                FlashcardEntity(topic = "Physics", question = "What is Heisenberg's Uncertainty Principle?", answer = "You cannot simultaneously measure both position and momentum of a particle with arbitrary precision.", difficulty = "Hard"),
                FlashcardEntity(topic = "General Knowledge", question = "What is the speed of light in vacuum?", answer = "Approximately 299,792,458 meters per second (~300,000 km/s).", difficulty = "Easy")
            )
            flashcardDao.insertFlashcards(starterCards)
        }

        // Seed default tasks if none
        val currentTasks = taskDao.getAllTasks().firstOrNull()
        if (currentTasks.isNullOrEmpty()) {
            taskDao.insertTask(TaskEntity(title = "Test Voice Assistant Mode", description = "Try talking to Nikhil AI using the Arc Reactor HUD", priority = "HIGH", dueDate = "Today"))
            taskDao.insertTask(TaskEntity(title = "Review Physics Flashcards", description = "Study quantum mechanics fundamentals", priority = "MEDIUM", dueDate = "Today"))
            taskDao.insertTask(TaskEntity(title = "Configure Gemini API Key", description = "Enter your secret key in Settings for live cloud intelligence", priority = "LOW", dueDate = "Tomorrow"))
        }

        // Seed initial session if none
        val sessions = chatDao.getAllSessions().firstOrNull()
        if (sessions.isNullOrEmpty()) {
            createNewSession("Primary Briefing", "JARVIS")
        }
    }

    suspend fun claimDailyReward(): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val profile = userProfileDao.getUserProfileOnce() ?: return@withContext Pair(false, "Profile unavailable")
        val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

        if (profile.lastCheckInDate == todayStr) {
            return@withContext Pair(false, "Daily reward already claimed today! Return tomorrow, Commander.")
        }

        val newStreak = profile.streakDays + 1
        val xpBonus = 60 + (newStreak * 10)
        val coinBonus = 25

        val updatedProfile = profile.copy(
            xp = profile.xp + xpBonus,
            coins = profile.coins + coinBonus,
            streakDays = newStreak,
            lastCheckInDate = todayStr
        )
        userProfileDao.insertOrUpdateProfile(calculateLevelAndTitle(updatedProfile))

        if (newStreak >= 7) {
            checkAchievement("streak_champion")
        }

        Pair(true, "Daily streak updated to Day $newStreak! +$xpBonus XP and +$coinBonus Coins added!")
    }

    suspend fun addXpAndCoins(xpGain: Int, coinGain: Int, isMessage: Boolean = false): Unit = withContext(Dispatchers.IO) {
        val profile = userProfileDao.getUserProfileOnce() ?: return@withContext
        val newCount = if (isMessage) profile.totalMessagesCount + 1 else profile.totalMessagesCount
        val updated = profile.copy(
            xp = profile.xp + xpGain,
            coins = profile.coins + coinGain,
            totalMessagesCount = newCount
        )
        userProfileDao.insertOrUpdateProfile(calculateLevelAndTitle(updated))

        if (isMessage && newCount >= 1) {
            checkAchievement("first_contact")
        }
    }

    suspend fun checkAchievement(achievementId: String): Unit = withContext(Dispatchers.IO) {
        val achievementsList = userProfileDao.getAllAchievements().firstOrNull() ?: return@withContext
        val target = achievementsList.find { it.id == achievementId }
        if (target != null && !target.isUnlocked) {
            val unlocked = target.copy(isUnlocked = true, unlockedAt = System.currentTimeMillis())
            userProfileDao.updateAchievement(unlocked)
            addXpAndCoins(target.xpReward, target.xpReward / 2)
        }
    }

    private fun calculateLevelAndTitle(profile: UserProfileEntity): UserProfileEntity {
        val level = (profile.xp / 250) + 1
        val title = when (level) {
            1 -> "Quantum Initiate"
            2 -> "Cyber Pilot"
            3 -> "Neural Architect"
            4 -> "AI Vanguard"
            5 -> "Quantum Commander"
            else -> "JARVIS Grandmaster"
        }
        return profile.copy(level = level, userTitle = title)
    }
}
