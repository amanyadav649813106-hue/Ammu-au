package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.VoiceState
import com.example.ui.NikhilViewModel
import com.example.ui.components.IronManArcReactorVisualizer
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonRose

/**
 * Dedicated Pure Arc Reactor Screen.
 * Minimalist, ultra-clean design featuring exclusively the full-screen Iron Man Arc Reactor.
 * Everything is geared towards hands-free voice conversation with Ammu with zero visual clutter.
 */
@Composable
fun ArcReactorScreen(
    viewModel: NikhilViewModel,
    modifier: Modifier = Modifier
) {
    val voiceState by viewModel.voiceManager.voiceState.collectAsState()
    val recognizedText by viewModel.voiceManager.recognizedText.collectAsState()
    val audioRms by viewModel.voiceManager.audioRms.collectAsState()
    val isContinuousListening by viewModel.voiceManager.isContinuousListening.collectAsState()
    val messages by viewModel.messages.collectAsState()

    val lastAssistantMessage = messages.lastOrNull { it.role == "assistant" }?.content ?: ""
    var showOwnerDialog by remember { mutableStateOf(false) }

    if (showOwnerDialog) {
        com.example.ui.components.OwnerControlDialog(
            viewModel = viewModel,
            onDismiss = { showOwnerDialog = false }
        )
    }

    // Hindi Speech Recognizer Fallback Launcher
    val systemSpeechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val spokenMatches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val text = spokenMatches?.firstOrNull() ?: ""
            if (text.isNotBlank()) {
                viewModel.sendVoiceCommand(text)
            }
        }
    }

    fun triggerListening() {
        if (viewModel.voiceManager.isRecognitionAvailable()) {
            viewModel.toggleVoiceListening()
        } else {
            try {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "अम्मू से बोलिए कमांडर अमन...")
                }
                systemSpeechLauncher.launch(intent)
            } catch (_: Exception) {
                viewModel.toggleVoiceListening()
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF030D1A),
                        Color(0xFF02070F),
                        Color(0xFF000308)
                    )
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = { triggerListening() }
            )
            .testTag("arc_reactor_screen"),
        contentAlignment = Alignment.Center
    ) {
        // TOP MINIMAL HUD
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 16.dp, start = 20.dp, end = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Permanent Creator Badge
            Surface(
                color = Color.Black.copy(alpha = 0.65f),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberCyan.copy(alpha = 0.4f)),
                shadowElevation = 6.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(
                                when (voiceState) {
                                    VoiceState.LISTENING -> NeonEmerald
                                    VoiceState.SPEAKING -> CyberCyan
                                    VoiceState.PROCESSING -> NeonAmber
                                    VoiceState.ERROR -> NeonRose
                                    VoiceState.IDLE -> CyberCyan
                                }
                            )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "AMMU IS MADE BY AMAN",
                        color = CyberCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "⚡ PURE ARC REACTOR MARK-V ⚡",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 2.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        // CENTER: PURE FULL-SIZE ARC REACTOR
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            IronManArcReactorVisualizer(
                size = 310.dp,
                voiceState = voiceState,
                audioRms = audioRms,
                onClick = { triggerListening() },
                modifier = Modifier.testTag("pure_arc_reactor_orb")
            )

            Spacer(modifier = Modifier.height(16.dp))

            // State prompt indicator
            val statusColor = when (voiceState) {
                VoiceState.LISTENING -> NeonEmerald
                VoiceState.SPEAKING -> CyberCyan
                VoiceState.PROCESSING -> NeonAmber
                VoiceState.ERROR -> NeonRose
                VoiceState.IDLE -> CyberCyan.copy(alpha = 0.75f)
            }

            val statusText = when (voiceState) {
                VoiceState.LISTENING -> "🎙️ अम्मू सुन रही है... बोलिए कमांडर अमन"
                VoiceState.SPEAKING -> "🔊 अम्मू बोल रही है..."
                VoiceState.PROCESSING -> "⚡ कमांड प्रोसेस हो रहा है..."
                VoiceState.ERROR -> "⚠️ पुनः प्रयास करें..."
                VoiceState.IDLE -> "⚡ कोर सक्रिय • बात करने के लिए रिएक्टर टैप करें"
            }

            Surface(
                color = Color(0xFF040B14).copy(alpha = 0.85f),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, statusColor.copy(alpha = 0.35f))
            ) {
                Text(
                    text = statusText,
                    color = statusColor,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 7.dp),
                    textAlign = TextAlign.Center
                )
            }
        }

        // BOTTOM FLOATING TRANSCRIPT & MINIMAL CONTROLS
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(bottom = 16.dp, start = 20.dp, end = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Live Spoken / Reply Subtitle Capsule
            val activeText = when {
                voiceState == VoiceState.LISTENING && recognizedText.isNotBlank() -> "कमांडर: $recognizedText"
                voiceState == VoiceState.SPEAKING && lastAssistantMessage.isNotBlank() -> "अम्मू: $lastAssistantMessage"
                lastAssistantMessage.isNotBlank() -> "अम्मू: $lastAssistantMessage"
                else -> ""
            }

            AnimatedVisibility(
                visible = activeText.isNotBlank(),
                enter = fadeIn() + slideInVertically(initialOffsetY = { 30 }),
                exit = fadeOut() + slideOutVertically(targetOffsetY = { 30 })
            ) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    color = Color(0xFF040E1B).copy(alpha = 0.92f),
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberCyan.copy(alpha = 0.3f)),
                    shadowElevation = 8.dp
                ) {
                    Text(
                        text = activeText,
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Normal,
                        lineHeight = 18.sp,
                        textAlign = TextAlign.Center,
                        maxLines = 3,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                    )
                }
            }

            // Minimalist Quick Floating Tool Buttons
            Row(
                modifier = Modifier
                    .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(24.dp))
                    .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(24.dp))
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                // Mic Button
                IconButton(
                    onClick = { triggerListening() },
                    modifier = Modifier.size(38.dp)
                ) {
                    Icon(
                        imageVector = if (voiceState == VoiceState.LISTENING) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "माइक",
                        tint = if (voiceState == VoiceState.LISTENING) NeonEmerald else CyberCyan,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Stop Audio / Speak
                if (voiceState == VoiceState.SPEAKING) {
                    IconButton(
                        onClick = { viewModel.stopSpeaking() },
                        modifier = Modifier.size(38.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Stop,
                            contentDescription = "रोकें",
                            tint = NeonRose,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                }

                // Continuous Listening Toggle
                IconButton(
                    onClick = { viewModel.toggleContinuousListening(!isContinuousListening) },
                    modifier = Modifier.size(38.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                        contentDescription = "कंटीन्यूअस लिसनिंग",
                        tint = if (isContinuousListening) NeonEmerald else Color.White.copy(alpha = 0.4f),
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Security Shield & API Key Vault Button
                IconButton(
                    onClick = { showOwnerDialog = true },
                    modifier = Modifier.size(38.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = "सुरक्षा शील्ड & API Key",
                        tint = NeonEmerald,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
