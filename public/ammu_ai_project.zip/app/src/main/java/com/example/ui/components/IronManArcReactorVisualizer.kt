package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.service.VoiceState
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonRose
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * Authentic, Ultra-Detailed Iron Man Mark Arc Reactor Visualizer.
 * Features 10 distinct copper solenoids, high-voltage electric plasma discharge arcs,
 * dual rotating turbine rings, titanium mechanical casing, and an intensely glowing
 * vibranium core that reacts dynamically to voice RMS audio and speech states.
 */
@Composable
fun IronManArcReactorVisualizer(
    modifier: Modifier = Modifier,
    size: Dp = 320.dp,
    voiceState: VoiceState = VoiceState.IDLE,
    audioRms: Float = 0f,
    onClick: () -> Unit = {}
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ArcReactorMain")

    // State-based dynamic rotation speeds
    val turbineDuration = when (voiceState) {
        VoiceState.LISTENING -> 8000
        VoiceState.SPEAKING -> 5000
        VoiceState.PROCESSING -> 3000
        else -> 14000
    }

    val counterDuration = when (voiceState) {
        VoiceState.LISTENING -> 10000
        VoiceState.SPEAKING -> 6500
        VoiceState.PROCESSING -> 4000
        else -> 18000
    }

    // Turbine rotation angles
    val turbineAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(turbineDuration, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "turbineAngle"
    )

    val counterAngle by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(counterDuration, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "counterAngle"
    )

    // Pulsing core breathing
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (voiceState) {
                    VoiceState.LISTENING -> 600
                    VoiceState.SPEAKING -> 450
                    VoiceState.PROCESSING -> 350
                    else -> 1600
                },
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "arcPulseScale"
    )

    // Electric plasma flicker
    val plasmaFlicker by infiniteTransition.animateFloat(
        initialValue = 0.75f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(120, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "plasmaFlicker"
    )

    // Shockwave ripple expansion
    val shockwaveProgress by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (voiceState == VoiceState.SPEAKING || voiceState == VoiceState.LISTENING) 1200 else 2400,
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "shockwaveProgress"
    )

    // Dynamic state theme colors
    val primaryCyan = when (voiceState) {
        VoiceState.LISTENING -> NeonEmerald
        VoiceState.SPEAKING -> Color(0xFF00E5FF)
        VoiceState.PROCESSING -> NeonAmber
        VoiceState.ERROR -> NeonRose
        VoiceState.IDLE -> CyberCyan
    }

    val copperAmber = Color(0xFFD48B47)
    val copperDark = Color(0xFF8B4E1A)
    val titaniumDark = Color(0xFF141A24)
    val titaniumSilver = Color(0xFF38465C)

    val dynamicBoost = (audioRms / 8f).coerceIn(0f, 0.5f)
    val effectiveScale = pulseScale + dynamicBoost

    Box(
        modifier = modifier
            .size(size)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val center = Offset(size.toPx() / 2f, size.toPx() / 2f)
            val baseRadius = (size.toPx() / 2f) * 0.90f

            // 1. External Energy Shockwave Rings (Expanding outward when active)
            val shockwaveRadius = baseRadius * shockwaveProgress
            val shockwaveAlpha = (1f - ((shockwaveProgress - 0.35f) / 0.85f)).coerceIn(0f, 0.5f)
            drawCircle(
                color = primaryCyan.copy(alpha = shockwaveAlpha * (0.6f + dynamicBoost)),
                radius = shockwaveRadius,
                center = center,
                style = Stroke(width = 2.dp.toPx())
            )

            // 2. Ambient Plasma Halo
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryCyan.copy(alpha = 0.38f * plasmaFlicker),
                        primaryCyan.copy(alpha = 0.12f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = baseRadius * 1.25f
                ),
                radius = baseRadius * 1.20f,
                center = center
            )

            // 3. Outermost Mechanical Titanium Ring
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(titaniumSilver, titaniumDark, Color(0xFF080C14)),
                    center = center,
                    radius = baseRadius
                ),
                radius = baseRadius,
                center = center,
                style = Stroke(width = 10.dp.toPx())
            )

            // 20 Perimeter Mechanical Fastener Bolts
            for (i in 0 until 20) {
                val boltAngle = (i * 18) * (Math.PI / 180.0)
                val bx = (center.x + (baseRadius - 5.dp.toPx()) * cos(boltAngle)).toFloat()
                val by = (center.y + (baseRadius - 5.dp.toPx()) * sin(boltAngle)).toFloat()
                drawCircle(
                    color = Color.White.copy(alpha = 0.85f),
                    radius = 1.8.dp.toPx(),
                    center = Offset(bx, by)
                )
                drawCircle(
                    color = primaryCyan.copy(alpha = 0.5f),
                    radius = 3.2.dp.toPx(),
                    center = Offset(bx, by),
                    style = Stroke(width = 1.dp.toPx())
                )
            }

            // 4. Circular HUD Radar Calibration Scale (Tick marks)
            rotate(counterAngle, pivot = center) {
                drawCircle(
                    color = primaryCyan.copy(alpha = 0.25f),
                    radius = baseRadius * 0.92f,
                    center = center,
                    style = Stroke(
                        width = 1.5.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 8f, 14f, 8f), 0f)
                    )
                )

                for (i in 0 until 40) {
                    val angle = (i * 9) * (Math.PI / 180.0)
                    val isMajor = i % 4 == 0
                    val len = if (isMajor) 6.dp.toPx() else 3.5.dp.toPx()
                    val tStart = Offset(
                        (center.x + (baseRadius * 0.92f - len) * cos(angle)).toFloat(),
                        (center.y + (baseRadius * 0.92f - len) * sin(angle)).toFloat()
                    )
                    val tEnd = Offset(
                        (center.x + (baseRadius * 0.92f) * cos(angle)).toFloat(),
                        (center.y + (baseRadius * 0.92f) * sin(angle)).toFloat()
                    )
                    drawLine(
                        color = if (isMajor) primaryCyan.copy(alpha = 0.9f) else primaryCyan.copy(alpha = 0.4f),
                        start = tStart,
                        end = tEnd,
                        strokeWidth = if (isMajor) 1.8.dp.toPx() else 1.dp.toPx()
                    )
                }
            }

            // 5. Backlight Energy Channel (Glowing cyan trough under solenoids)
            val solenoidTrackRadius = baseRadius * 0.76f
            drawCircle(
                color = primaryCyan.copy(alpha = 0.42f * plasmaFlicker),
                radius = solenoidTrackRadius,
                center = center,
                style = Stroke(width = 24.dp.toPx())
            )

            // 6. 10 ICONIC COPPER SOLENOIDS (Arc Reactor Inductor Coils)
            // Each solenoid represents one of the 10 energy blocks of the Iron Man reactor
            val solenoidCount = 10
            for (idx in 0 until solenoidCount) {
                val segAngleDeg = idx * 36f
                val segAngleRad = segAngleDeg * (Math.PI / 180.0)

                rotate(segAngleDeg, pivot = center) {
                    val sx = center.x
                    val sy = center.y - solenoidTrackRadius
                    val sWidth = 24.dp.toPx()
                    val sHeight = 18.dp.toPx()

                    // Glowing backlight under each solenoid
                    drawRoundRect(
                        brush = Brush.radialGradient(
                            colors = listOf(primaryCyan.copy(alpha = 0.8f), primaryCyan.copy(alpha = 0.1f)),
                            center = Offset(sx, sy),
                            radius = sWidth * 1.2f
                        ),
                        topLeft = Offset(sx - sWidth / 2f - 3.dp.toPx(), sy - sHeight / 2f - 3.dp.toPx()),
                        size = Size(sWidth + 6.dp.toPx(), sHeight + 6.dp.toPx()),
                        cornerRadius = CornerRadius(4.dp.toPx())
                    )

                    // Copper solenoid core block
                    drawRoundRect(
                        brush = Brush.horizontalGradient(
                            colors = listOf(copperDark, copperAmber, Color(0xFFF0B36C), copperDark),
                            startX = sx - sWidth / 2f,
                            endX = sx + sWidth / 2f
                        ),
                        topLeft = Offset(sx - sWidth / 2f, sy - sHeight / 2f),
                        size = Size(sWidth, sHeight),
                        cornerRadius = CornerRadius(3.dp.toPx())
                    )

                    // 4 Wound copper wire grooves
                    for (wire in 0 until 4) {
                        val wireY = (sy - sHeight / 2f) + (wire + 1) * (sHeight / 5f)
                        drawLine(
                            color = Color(0xFF3E1B05),
                            start = Offset(sx - sWidth / 2f, wireY),
                            end = Offset(sx + sWidth / 2f, wireY),
                            strokeWidth = 1.2.dp.toPx()
                        )
                    }

                    // Top metallic holding clamp
                    drawRect(
                        color = titaniumSilver,
                        topLeft = Offset(sx - sWidth * 0.28f, sy - sHeight / 2f - 2.dp.toPx()),
                        size = Size(sWidth * 0.56f, 3.5.dp.toPx())
                    )

                    // Bottom metallic holding clamp
                    drawRect(
                        color = titaniumSilver,
                        topLeft = Offset(sx - sWidth * 0.28f, sy + sHeight / 2f - 1.5.dp.toPx()),
                        size = Size(sWidth * 0.56f, 3.5.dp.toPx())
                    )
                }
            }

            // 7. Middle Glass Retaining Ring with Turbine Slots
            val midRingRadius = baseRadius * 0.58f
            drawCircle(
                color = Color(0xFF0F1722),
                radius = midRingRadius,
                center = center,
                style = Fill
            )
            drawCircle(
                color = primaryCyan.copy(alpha = 0.55f),
                radius = midRingRadius,
                center = center,
                style = Stroke(width = 2.dp.toPx())
            )

            // Inner Rotating Turbine Fins
            rotate(turbineAngle, pivot = center) {
                val finCount = 10
                for (f in 0 until finCount) {
                    val angle = (f * 36) * (Math.PI / 180.0)
                    val finInner = Offset(
                        (center.x + (midRingRadius * 0.65f) * cos(angle)).toFloat(),
                        (center.y + (midRingRadius * 0.65f) * sin(angle)).toFloat()
                    )
                    val finOuter = Offset(
                        (center.x + (midRingRadius * 0.95f) * cos(angle)).toFloat(),
                        (center.y + (midRingRadius * 0.95f) * sin(angle)).toFloat()
                    )
                    drawLine(
                        color = primaryCyan.copy(alpha = 0.75f),
                        start = finInner,
                        end = finOuter,
                        strokeWidth = 2.5.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
            }

            // 8. HIGH-VOLTAGE ELECTRIC PLASMA ARCS (Crackling between Core and Solenoids)
            val randomSeed = (System.currentTimeMillis() / 80).toInt()
            val rng = Random(randomSeed)
            val arcCount = if (voiceState == VoiceState.SPEAKING || voiceState == VoiceState.LISTENING) 5 else 3

            for (arc in 0 until arcCount) {
                val targetSolenoid = (rng.nextInt(10)) * 36
                val targetRad = targetSolenoid * (Math.PI / 180.0)
                val targetX = (center.x + solenoidTrackRadius * 0.9f * cos(targetRad)).toFloat()
                val targetY = (center.y + solenoidTrackRadius * 0.9f * sin(targetRad)).toFloat()

                val coreBoundary = midRingRadius * 0.5f * effectiveScale
                val startX = (center.x + coreBoundary * cos(targetRad)).toFloat()
                val startY = (center.y + coreBoundary * sin(targetRad)).toFloat()

                // Draw zigzag lightning path
                val lightningPath = Path().apply {
                    moveTo(startX, startY)
                    val mid1 = Offset(
                        (startX + targetX) / 2f + rng.nextInt(-14, 15).dp.toPx(),
                        (startY + targetY) / 2f + rng.nextInt(-14, 15).dp.toPx()
                    )
                    lineTo(mid1.x, mid1.y)
                    lineTo(targetX, targetY)
                }

                drawPath(
                    path = lightningPath,
                    color = primaryCyan.copy(alpha = (0.7f * plasmaFlicker).coerceIn(0.3f, 1f)),
                    style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                )

                // Pure white lightning core
                drawPath(
                    path = lightningPath,
                    color = Color.White.copy(alpha = 0.9f),
                    style = Stroke(width = 1.dp.toPx(), cap = StrokeCap.Round)
                )
            }

            // 9. CENTRAL VIBRANIUM/PALLADIUM NUCLEUS CORE
            val coreRadius = midRingRadius * 0.52f * effectiveScale

            // Glowing Outer Core Aura
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White,
                        primaryCyan,
                        primaryCyan.copy(alpha = 0.45f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = coreRadius * 1.8f
                ),
                radius = coreRadius * 1.6f,
                center = center
            )

            // Inner Metallic Core Bezel
            drawCircle(
                color = Color(0xFF070B12),
                radius = coreRadius,
                center = center,
                style = Fill
            )
            drawCircle(
                color = primaryCyan,
                radius = coreRadius,
                center = center,
                style = Stroke(width = 2.5.dp.toPx())
            )

            // Inscribed Triangular Energy Nexus Prism (Tony Stark's Triangle Core)
            rotate(counterAngle * 0.5f, pivot = center) {
                val triRadius = coreRadius * 0.78f
                val triPath = Path().apply {
                    for (v in 0 until 3) {
                        val vAngle = (v * 120 - 90) * (Math.PI / 180.0)
                        val vx = (center.x + triRadius * cos(vAngle)).toFloat()
                        val vy = (center.y + triRadius * sin(vAngle)).toFloat()
                        if (v == 0) moveTo(vx, vy) else lineTo(vx, vy)
                    }
                    close()
                }

                drawPath(
                    path = triPath,
                    brush = Brush.radialGradient(
                        colors = listOf(Color.White, primaryCyan.copy(alpha = 0.6f)),
                        center = center,
                        radius = triRadius
                    ),
                    style = Fill
                )
                drawPath(
                    path = triPath,
                    color = Color.White,
                    style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                )
            }

            // Central White-Hot Energy Pearl
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.White, primaryCyan, Color.Transparent),
                    center = center,
                    radius = coreRadius * 0.45f
                ),
                radius = coreRadius * 0.42f,
                center = center
            )
        }
    }
}
