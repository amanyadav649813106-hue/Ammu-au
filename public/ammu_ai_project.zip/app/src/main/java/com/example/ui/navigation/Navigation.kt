package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.RemoveRedEye
import androidx.compose.ui.graphics.vector.ImageVector

enum class AppDestination(
    val title: String,
    val icon: ImageVector
) {
    ARC_REACTOR("आर्क रिएक्टर", Icons.Default.Bolt),
    VOICE_HUD("वॉयस ऑर्ब", Icons.Default.GraphicEq),
    CHAT("अम्मू चैट", Icons.Default.ChatBubble),
    CONTROLS("कंट्रोल डेक", Icons.Default.PhoneAndroid),
    SCREEN_GUARDIAN("स्क्रीन & GPS", Icons.Default.RemoveRedEye)
}

